import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-patientreports',
  templateUrl: './patientreports.component.html',
  styleUrls: ['./patientreports.component.scss']
})
export class PatientreportsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
