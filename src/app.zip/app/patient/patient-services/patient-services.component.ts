import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-patient-services',
  templateUrl: './patient-services.component.html',
  styleUrls: ['./patient-services.component.scss']
})
export class PatientServicesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
