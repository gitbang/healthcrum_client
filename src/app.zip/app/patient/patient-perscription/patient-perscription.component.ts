import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-patient-perscription',
  templateUrl: './patient-perscription.component.html',
  styleUrls: ['./patient-perscription.component.scss']
})
export class PatientPerscriptionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
