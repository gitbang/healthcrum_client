import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-doctor',
  templateUrl: './view-doctor.component.html',
  styleUrls: ['./view-doctor.component.scss']
})
export class ViewDoctorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
