import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-patient-apponitments',
  templateUrl: './patient-apponitments.component.html',
  styleUrls: ['./patient-apponitments.component.scss']
})
export class PatientApponitmentsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
