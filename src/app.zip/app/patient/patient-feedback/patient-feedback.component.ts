import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-patient-feedback',
  templateUrl: './patient-feedback.component.html',
  styleUrls: ['./patient-feedback.component.scss']
})
export class PatientFeedbackComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
