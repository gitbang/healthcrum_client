import { Component, OnInit } from "@angular/core";
// import { MapLocationSelectorComponent } from "../shared/map-location-selector/map-location-selector.component";
import { FormBuilder, FormControl } from "@angular/forms";
// import { MatDialog } from "@angular/material";
import { MouseEvent } from "@agm/core";
import { HttpClient } from "@angular/common/http";
@Component({
  selector: "app-corporate-entry",
  templateUrl: "./corporate-entry.component.html",
  styleUrls: ["./corporate-entry.component.scss"],
})
export class CorporateEntryComponent implements OnInit {
  map_response: any;

  register = this.fb.group({
    lab_logo: new FormControl(),
    lab_name: new FormControl(),
    state: new FormControl(),
    city: new FormControl(),
    add: new FormControl(),
    contact_number: new FormControl(),
  });

  constructor(private fb: FormBuilder, private httpClient: HttpClient) {}

  ngOnInit() {}

  zoom: number = 8;
  lat: number = 22.427095946682467;
  lng: number = 79.92415996874999;

  clickedMarker(label: string, index: number) {}

  mapClicked($event: MouseEvent) {
    this.marker.lat = $event.coords.lat;
    this.marker.lng = $event.coords.lng;
    this.getAddressDetails($event.coords.lat, $event.coords.lng);
  }

  markerDragEnd(m: marker, $event: MouseEvent) {
    this.getAddressDetails($event.coords.lat, $event.coords.lng);
  }

  marker: marker = {
    lat: this.lat,
    lng: this.lng,
    label: "M",
    draggable: true,
  };

  public getAddressDetails(lat, long) {
    let url = `https://api.opencagedata.com/geocode/v1/json?q=${lat}+${long}&key=ef023180e56342a193ff4b658e2f02dd`;
    this.httpClient.get(url).subscribe((res: any) => {
      console.log(res);
      if (res.results.length > 0) {
        let data = res.results[0].components;
        // let add_full = res.result[0].formatted;
        this.register.get("state").setValue(data.state);
        this.register.get("city").setValue(data.state_district);
        this.register.get("add").setValue(res.results[0].formatted);
      }
    });
  }
}

// interface for type safety.
interface marker {
  lat: number;
  lng: number;
  label?: string;
  draggable: boolean;
}
