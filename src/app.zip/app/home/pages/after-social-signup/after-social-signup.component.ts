import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-after-social-signup',
  templateUrl: './after-social-signup.component.html',
  styleUrls: ['./after-social-signup.component.scss']
})
export class AfterSocialSignupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
