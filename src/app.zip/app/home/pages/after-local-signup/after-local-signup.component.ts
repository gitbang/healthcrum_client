import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-after-local-signup',
  templateUrl: './after-local-signup.component.html',
  styleUrls: ['./after-local-signup.component.scss']
})
export class AfterLocalSignupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
