import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-oders',
  templateUrl: './oders.component.html',
  styleUrls: ['./oders.component.scss']
})
export class OdersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
