import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-perscription',
  templateUrl: './perscription.component.html',
  styleUrls: ['./perscription.component.scss']
})
export class PerscriptionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
